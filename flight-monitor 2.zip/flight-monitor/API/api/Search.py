export default async function handler(req, res) {
  try {
    const { startDate, endDate } = req.query;

    const url = `https://blue-scraper.p.rapidapi.com/1.0/flights/search-roundtrip?originSkyId=SAO&destinationSkyId=MCO&departureDate=${startDate}&returnDate=${endDate}&currency=BRL`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "x-rapidapi-host": "blue-scraper.p.rapidapi.com",
        "x-rapidapi-key": process.env.RAPIDAPI_KEY
      }
    });

    const data = await response.json();
    res.status(200).json(data);

  } catch (e) {
    res.status(500).json({ error: "Erro ao buscar voos", details: e.toString() });
  }
}
